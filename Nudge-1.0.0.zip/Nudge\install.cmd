@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  Nudge 安裝（捷徑 / 開機自動啟動）…
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install.ps1" %*
echo.
pause
