﻿# 由 update.ps1 在 Nudge 結束後啟動：備份舊檔 → 換成新檔 → 重新啟動 Nudge；任何一步失敗就把舊檔還原。
# 絕不碰 .nudge（你的資料、AI 設定、金鑰、設定都在那裡）。
param([int]$ProcId, [string]$Src, [string]$Dst, [string]$Backup, [string]$Exe, [string]$LogFile)
$ErrorActionPreference = 'Stop'
function W($m) { try { New-Item -ItemType Directory -Force (Split-Path $LogFile) | Out-Null; Add-Content -LiteralPath $LogFile -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) } catch {} }
W "apply start: $Src -> $Dst"
try { if ($ProcId) { Wait-Process -Id $ProcId -Timeout 30 -ErrorAction SilentlyContinue } } catch {}
Start-Sleep -Milliseconds 500
$srcFull = [IO.Path]::GetFullPath($Src).TrimEnd('\') + '\'
$dstFull = [IO.Path]::GetFullPath($Dst).TrimEnd('\') + '\'
$done = New-Object System.Collections.Generic.List[object]       # @{rel; hadOld}
$ok = $true
try {
  New-Item -ItemType Directory -Force $Backup | Out-Null
  foreach ($f in Get-ChildItem -LiteralPath $Src -Recurse -File) {
    $rel = $f.FullName.Substring($srcFull.Length)
    if ($rel -like '.nudge*' -or $rel -like '*..*') { continue }
    $dest = [IO.Path]::GetFullPath((Join-Path $Dst $rel))
    if (-not $dest.StartsWith($dstFull, [StringComparison]::OrdinalIgnoreCase)) { throw "unsafe path: $rel" }
    $had = Test-Path -LiteralPath $dest
    if ($had) {
      $bk = Join-Path $Backup $rel; New-Item -ItemType Directory -Force (Split-Path $bk) | Out-Null
      Copy-Item -LiteralPath $dest -Destination $bk -Force
      if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -eq (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash) { continue }   # 沒變的不動
    }
    New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
    $tries = 0
    while ($true) { try { Copy-Item -LiteralPath $f.FullName -Destination $dest -Force; break } catch { $tries++; if ($tries -ge 6) { throw }; Start-Sleep -Milliseconds 500 } }
    $done.Add(@{ rel = $rel; had = $had }); W "updated $rel"
  }
  W "apply ok ($($done.Count) files changed)"
} catch {
  $ok = $false; W "FAILED: $($_.Exception.Message) -> rolling back"
  foreach ($d in $done) {
    try {
      $dest = Join-Path $Dst $d.rel
      if ($d.had) { Copy-Item -LiteralPath (Join-Path $Backup $d.rel) -Destination $dest -Force } else { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
    } catch { W "rollback error on $($d.rel): $($_.Exception.Message)" }
  }
  W 'rollback done'
}
# 只留最近 3 份備份
try { Get-ChildItem -LiteralPath (Split-Path $Backup) -Directory -Filter 'backup-*' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 3 | Remove-Item -Recurse -Force } catch {}
if ($Exe -and (Test-Path -LiteralPath $Exe)) { Start-Process -FilePath $Exe; W "restarted $Exe (ok=$ok)" }
