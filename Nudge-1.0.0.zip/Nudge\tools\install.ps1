﻿# 安裝（使用者層級，不需系統管理員）：
#   1. 編譯 Nudge.exe（內嵌 @ 圖示）
#   2. 捷徑：專案資料夾、桌面、「開始」功能表（都帶 @ 圖示）
#   3. 開機自動啟動：登錄檔 Run + 啟動資料夾（兩者同時觸發也只會有一個程式，tray.ps1 有單一執行個體保護）
#      ⚠ 不要用「工作排程器」：實測由排程器啟動的程式會看到另一份獨立的資料夾，筆記會「全部不見」。
# 用法：powershell -ExecutionPolicy Bypass -File tools\install.ps1 [-Uninstall]
param([switch]$Uninstall, [switch]$Force)
# ⚠ 必須在「Windows 本身」執行（雙擊專案資料夾的 install.cmd），不要從 Claude 裡面執行：
#   Claude 桌面程式是 MSIX 封裝，它啟動的程式寫入 AppData／登錄檔（HKCU）／開始功能表時會被導到私有的虛擬區，
#   Windows 真正的桌面、開始功能表、開機啟動項目都看不到，等於白做。
function Test-InClaude {
  $id = $PID
  for ($i = 0; $i -lt 15 -and $id; $i++) {
    $p = Get-CimInstance Win32_Process -Filter "ProcessId=$id" -ErrorAction SilentlyContinue
    if (-not $p) { break }
    if ($p.ExecutablePath -like '*\WindowsApps\Claude_*') { return $true }
    $id = $p.ParentProcessId
  }
  return $false
}
if (-not $Force -and (Test-InClaude)) {
  Write-Output '這個安裝腳本是從 Claude 裡面執行的，建立的捷徑與開機啟動項目會被導到虛擬區，Windows 看不到。'
  Write-Output '請改在檔案總管裡「雙擊 install.cmd」（或在一般的 PowerShell 視窗執行）。（要強制執行請加 -Force）'
  exit 2
}
$ErrorActionPreference = 'Stop'
# 從網路下載的 zip 解壓縮出來的檔案可能帶有「網路來源」標記，先全部解除（只影響這個資料夾）
Get-ChildItem -LiteralPath (Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)) -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$exe  = Join-Path $root 'Nudge.exe'
$ico  = Join-Path $root 'assets\nudge.ico'
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$lnks = @((Join-Path $root 'Nudge.lnk'), (Join-Path $desktop 'Nudge.lnk'), (Join-Path $startMenu 'Nudge.lnk'))

if ($Uninstall) {
  $lnks | ForEach-Object { if (Test-Path -LiteralPath $_) { Remove-Item -LiteralPath $_ } }
  Unregister-ScheduledTask -TaskName 'Nudge' -Confirm:$false -ErrorAction SilentlyContinue
  $sp = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\Nudge.lnk'; if (Test-Path -LiteralPath $sp) { Remove-Item -LiteralPath $sp }
  Remove-ItemProperty -Path $runKey -Name 'Nudge' -ErrorAction SilentlyContinue
  "已移除：捷徑、啟動資料夾、Run 項目、排程工作（若有）（程式檔案與你的筆記資料沒有動）"; return
}

# 1) 圖示與 exe
if (-not (Test-Path -LiteralPath $ico)) { & (Join-Path $PSScriptRoot 'make-icon.ps1') | Out-Null }
$csc = (Get-ChildItem 'C:\Windows\Microsoft.NET\Framework64' -Filter csc.exe -Recurse | Sort-Object FullName | Select-Object -Last 1).FullName
& $csc /nologo /target:winexe "/win32icon:$ico" /r:System.Management.dll "/out:$exe" (Join-Path $PSScriptRoot 'launcher.cs')
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $exe)) { throw 'Nudge.exe 編譯失敗' }
"exe: $exe ($((Get-Item $exe).Length) bytes)"

# 2) 捷徑（桌面可能被 OneDrive 重新導向，用系統回報的實際路徑）
$sh = New-Object -ComObject WScript.Shell
foreach ($l in $lnks) {
  $s = $sh.CreateShortcut($l)
  $s.TargetPath = $exe; $s.WorkingDirectory = $root; $s.IconLocation = "$exe,0"; $s.Description = 'Nudge'
  $s.Save(); "shortcut: $l"
}
# 舊的「wscript + start.vbs」捷徑殘留（若有）一併清掉
$old = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\Nudge.lnk'
if (Test-Path -LiteralPath $old) { Remove-Item -LiteralPath $old }

# 3) 開機自動啟動
Set-ItemProperty -Path $runKey -Name 'Nudge' -Value ('"' + $exe + '"')
"run key: $((Get-ItemProperty $runKey).Nudge)"
# 注意：不要用「工作排程器」：實測由排程器啟動的程式會看到另一份獨立（空）的資料夾，開機後筆記會「全部不見」。
Unregister-ScheduledTask -TaskName 'Nudge' -Confirm:$false -ErrorAction SilentlyContinue
# 第二道保險：啟動資料夾（登錄檔 Run 沒觸發時，由 Explorer 啟動；兩邊同時觸發也只會有一個程式）
$startup = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\Nudge.lnk'
$s2 = $sh.CreateShortcut($startup); $s2.TargetPath = $exe; $s2.WorkingDirectory = $root; $s2.IconLocation = "$exe,0"; $s2.Save()
"startup folder: $startup"
