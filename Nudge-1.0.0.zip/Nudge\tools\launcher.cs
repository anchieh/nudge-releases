// Nudge.exe：極小的啟動器（無視窗）。作用只有兩個：
//   1. 在 <程式資料夾>\.nudge\launcher.log 記一行「啟動器有被執行」（開機沒出現時，用它判斷是誰沒動）
//   2. 以隱藏視窗執行同資料夾的 tray.ps1
// 編譯：tools\install.ps1 會呼叫 .NET Framework 內建的 csc.exe，並嵌入 assets\nudge.ico
using System;
using System.Diagnostics;
using System.IO;

static class Program
{
    static string ParentName()
    {
        try
        {
            using (var q = new System.Management.ManagementObjectSearcher("SELECT ParentProcessId FROM Win32_Process WHERE ProcessId=" + Process.GetCurrentProcess().Id))
                foreach (System.Management.ManagementObject o in q.Get())
                    try { return Process.GetProcessById(Convert.ToInt32(o["ParentProcessId"])).ProcessName; } catch { return "exited:" + o["ParentProcessId"]; }
        }
        catch { }
        return "?";
    }

    [STAThread]
    static int Main()
    {
        string dir = AppDomain.CurrentDomain.BaseDirectory;
        string data = Path.Combine(dir, ".nudge");     // 與 tray.ps1 一致：狀態放在程式資料夾，不放 AppData（見 tray.ps1 的說明）
        string log = Path.Combine(data, "launcher.log");
        string who = Environment.UserName + " session=" + Process.GetCurrentProcess().SessionId + " parent=" + ParentName();
        try { Directory.CreateDirectory(data); File.AppendAllText(log, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  launcher started (" + who + ")\r\n"); }
        catch (Exception e)
        {   // 寫不進主要位置時，退而寫到暫存資料夾，並記下原因
            try { File.AppendAllText(Path.Combine(Path.GetTempPath(), "nudge-launcher.log"), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  could not write " + log + ": " + e.Message + "\r\n"); } catch { }
        }

        string script = Path.Combine(dir, "tray.ps1");
        if (!File.Exists(script))
        {
            try { File.AppendAllText(log, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  ERROR tray.ps1 not found: " + script + "\r\n"); } catch { }
            return 2;
        }
        try
        {
            var psi = new ProcessStartInfo("powershell.exe",
                "-NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + script + "\"")
            { CreateNoWindow = true, UseShellExecute = false, WorkingDirectory = dir };
            Process.Start(psi);
            return 0;
        }
        catch (Exception e)
        {
            try { File.AppendAllText(log, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  ERROR " + e.Message + "\r\n"); } catch { }
            return 1;
        }
    }
}
