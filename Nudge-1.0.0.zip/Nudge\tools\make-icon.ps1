﻿# 產生 assets\nudge.ico（藍底白色 @，16～256 px 多尺寸）與捷徑 Nudge.lnk（用這個圖示）。
# 格式：16～128 px 用傳統 BMP(DIB) 項目（相容性最好），256 px 用 PNG（標準做法）。
# 用法：powershell -ExecutionPolicy Bypass -File tools\make-icon.ps1 [-StartMenu]
#   -StartMenu：另外把捷徑放進「開始」功能表（所有應用程式清單與搜尋找得到 Nudge）
param([switch]$StartMenu)
Add-Type -AssemblyName System.Drawing
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$icoPath = Join-Path $root 'assets\nudge.ico'
New-Item -ItemType Directory -Force (Split-Path $icoPath) | Out-Null

function New-Bitmap([int]$size) {
  $bmp = New-Object System.Drawing.Bitmap $size, $size, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = 'AntiAlias'; $g.TextRenderingHint = 'AntiAliasGridFit'
  $g.Clear([System.Drawing.Color]::FromArgb(255, 37, 99, 235))
  $font = New-Object System.Drawing.Font('Segoe UI', ($size * 29 / 32), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
  $sf = New-Object System.Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
  $g.DrawString('@', $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF 0, ($size * 0.5 / 32), $size, $size), $sf)
  $g.Dispose()
  return $bmp
}
function To-Png($bmp) { $ms = New-Object System.IO.MemoryStream; $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); return ,$ms.ToArray() }
function To-Dib($bmp) {
  $n = $bmp.Width
  $rect = New-Object System.Drawing.Rectangle 0, 0, $n, $n
  $d = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
  $raw = New-Object byte[] ($d.Stride * $n); [System.Runtime.InteropServices.Marshal]::Copy($d.Scan0, $raw, 0, $raw.Length); $bmp.UnlockBits($d)
  $ms = New-Object System.IO.MemoryStream; $w = New-Object System.IO.BinaryWriter $ms
  $w.Write([uint32]40); $w.Write([int32]$n); $w.Write([int32](2 * $n)); $w.Write([uint16]1); $w.Write([uint16]32)   # BITMAPINFOHEADER（高度 = 2×，含遮罩）
  $w.Write([uint32]0); $w.Write([uint32]($n * $n * 4)); $w.Write([int32]0); $w.Write([int32]0); $w.Write([uint32]0); $w.Write([uint32]0)
  for ($y = $n - 1; $y -ge 0; $y--) { $w.Write($raw, $y * $d.Stride, $n * 4) }                                        # 像素：由下往上，BGRA
  $maskRow = [int]([Math]::Ceiling($n / 32.0) * 4)
  $w.Write((New-Object byte[] ($maskRow * $n)))                                                                       # AND 遮罩：全 0 = 不透明（透明度靠 alpha）
  $w.Flush(); return ,$ms.ToArray()
}

$sizes = 16, 24, 32, 48, 64, 128, 256
$data = foreach ($sz in $sizes) { $b = New-Bitmap $sz; if ($sz -ge 256) { , (To-Png $b) } else { , (To-Dib $b) }; $b.Dispose() }
$fs = [System.IO.File]::Create($icoPath); $bw = New-Object System.IO.BinaryWriter $fs
$bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]$sizes.Count)                                           # ICONDIR
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {                                                                              # ICONDIRENTRY
  $sz = $sizes[$i]; $wh = if ($sz -ge 256) { 0 } else { $sz }
  $bw.Write([byte]$wh); $bw.Write([byte]$wh); $bw.Write([byte]0); $bw.Write([byte]0)
  $bw.Write([uint16]1); $bw.Write([uint16]32); $bw.Write([uint32]$data[$i].Length); $bw.Write([uint32]$offset)
  $offset += $data[$i].Length
}
foreach ($p in $data) { $bw.Write($p) }
$bw.Close(); $fs.Close()
"icon: $icoPath ($((Get-Item $icoPath).Length) bytes)"

# 捷徑（含絕對路徑，因此不放進 git；每台電腦各自執行本腳本產生）
$lnk = Join-Path $root 'Nudge.lnk'
$s = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$s.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
$s.Arguments = '"' + (Join-Path $root 'start.vbs') + '"'
$s.WorkingDirectory = $root; $s.IconLocation = $icoPath + ',0'; $s.WindowStyle = 7; $s.Description = 'Nudge'
$s.Save()
"shortcut: $lnk"
if ($StartMenu) {
  $sm = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
  Copy-Item -LiteralPath $lnk -Destination (Join-Path $sm 'Nudge.lnk') -Force
  "start menu: $(Join-Path $sm 'Nudge.lnk')"
}
