﻿# Nudge：系統匣常駐 + 全域快速鍵 + 停靠右側的側邊欄視窗（WebView2 顯示 ui/index.html）
# 視窗沒有可用的關閉鈕（只有最小化／最大化）；離開只能走「檔案 → 結束」或托盤右鍵「結束」。
Add-Type -ReferencedAssemblies System.Windows.Forms -TypeDefinition @"
using System; using System.Windows.Forms; using System.Runtime.InteropServices;
public class HotKeyWindow : NativeWindow, IDisposable {
  [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
  [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
  [DllImport("kernel32.dll")] static extern bool SetProcessWorkingSetSize(IntPtr p, IntPtr min, IntPtr max);
  [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
  [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
  public static void DpiAware() { SetProcessDPIAware(); }
  // 讓工作列把 Nudge 視為獨立的程式（否則會歸給 powershell.exe、顯示 PowerShell 的圖示）
  [DllImport("shell32.dll")] static extern int SetCurrentProcessExplicitAppUserModelID([MarshalAs(UnmanagedType.LPWStr)] string id);
  public static void AppId(string id) { SetCurrentProcessExplicitAppUserModelID(id); }
  public static void Trim() { SetProcessWorkingSetSize(GetCurrentProcess(), (IntPtr)(-1), (IntPtr)(-1)); }
  public event Action Pressed;
  public bool Ok;
  public HotKeyWindow(uint mod, uint vk) { CreateHandle(new CreateParams()); Ok = RegisterHotKey(Handle, 1, mod, vk); }
  protected override void WndProc(ref Message m) { if (m.Msg == 0x0312 && Pressed != null) Pressed(); base.WndProc(ref m); }
  public void Dispose() { UnregisterHotKey(Handle, 1); DestroyHandle(); }
}
// CS_NOCLOSE：視窗右上角的關閉鈕反灰、Alt+F4 無效；深色標題列
public class NudgeForm : Form {
  [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int v, int size);
  protected override CreateParams CreateParams { get { var cp = base.CreateParams; cp.ClassStyle |= 0x200; return cp; } }
  protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); int v = 1; DwmSetWindowAttribute(Handle, 20, ref v, 4); }
}
"@
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[HotKeyWindow]::DpiAware()   # 實體像素座標：1/3、1/4 寬度才精確，文字也不會被放大模糊
[HotKeyWindow]::AppId('Nudge.App')   # 工作列／開始功能表用這個身分，而不是 powershell.exe

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Add-Type -Path (Join-Path $root 'lib\Microsoft.Web.WebView2.Core.dll')
Add-Type -Path (Join-Path $root 'lib\Microsoft.Web.WebView2.WinForms.dll')

$page    = ([Uri](Join-Path $root 'ui\index.html')).AbsoluteUri
# 所有狀態（資料、設定、紀錄、WebView2 設定檔）都放在「程式資料夾\.nudge」。
# 不放在 %LOCALAPPDATA%：從 Claude（MSIX 封裝）啟動時，AppData 會被導到私有的虛擬區，Windows 真實的 AppData 看不到，
# 結果「從 Claude 啟動」與「從桌面啟動」會各看到一份不同的資料（筆記像是全部不見）。專案資料夾兩邊看到的是同一份。
$dataDir = Join-Path $root '.nudge'
$wvData  = Join-Path $dataDir 'webview2'          # WebView2 的資料夾（瀏覽器設定檔／快取；筆記本身存在資料檔）
$cfgFile = Join-Path $dataDir 'settings.txt'      # 視窗寬度比例：3 = 1/3、4 = 1/4
$script:form = $null; $script:web = $null; $script:quitting = $false
$script:frac = 3
try { $script:frac = [int](Get-Content $cfgFile -ErrorAction Stop) } catch {}
if ($script:frac -ne 3 -and $script:frac -ne 4) { $script:frac = 3 }
New-Item -ItemType Directory -Force $dataDir | Out-Null
# 介面語言（zh / en）：由畫面右上角的 EN／中文 切換，記在 .nudge\lang.txt；外殼自己的選單與訊息用 L '中文' 'English' 取字
$langFile = Join-Path $dataDir 'lang.txt'
$script:lang = 'zh'
try { if ((Get-Content -LiteralPath $langFile -ErrorAction Stop | Select-Object -First 1).Trim() -eq 'en') { $script:lang = 'en' } } catch {}
function L([string]$zh, [string]$en) { if ($script:lang -eq 'en') { $en } else { $zh } }

# 單一執行個體
$mutex = New-Object System.Threading.Mutex($false, 'Local\ATTaskTray')
if (-not $mutex.WaitOne(0)) { exit }
try { Add-Content (Join-Path $dataDir 'startup.log') ("{0}  started pid={1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $PID) } catch {}   # 開機自動啟動有沒有成功、何時啟動，查這個檔

# 圖示：藍底白色 @，程式內繪製
$bmp = New-Object System.Drawing.Bitmap 32, 32
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = 'AntiAlias'; $g.TextRenderingHint = 'AntiAliasGridFit'; $g.Clear([System.Drawing.Color]::FromArgb(37, 99, 235))
$font = New-Object System.Drawing.Font('Segoe UI', 29, [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
$sf = New-Object System.Drawing.StringFormat; $sf.Alignment = 'Center'; $sf.LineAlignment = 'Center'
$g.DrawString('@', $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF 0, 0.5, 32, 32), $sf)
$g.Dispose()
$icon = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
# 視窗／工作列用多尺寸的 assets\nudge.ico（比較清晰）；找不到就用上面畫的小圖示
$winIcon = $icon
try { $winIcon = New-Object System.Drawing.Icon (Join-Path $root 'assets\nudge.ico') } catch {}

function Log($e) { try { $e | Out-String | Add-Content (Join-Path $dataDir 'error.log') } catch {} }

# 停靠螢幕右側，寬度 = 工作區的 1/3 或 1/4，高度填滿
function Set-Dock([int]$frac) {
  $script:frac = $frac
  try { Set-Content $cfgFile $frac } catch {}
  if (-not $script:form) { return }
  $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
  $w = [Math]::Max(440, [int]($wa.Width / $frac))   # 最小 440px，避免內容擠壞
  $script:form.WindowState = 'Normal'
  $script:form.Bounds = New-Object System.Drawing.Rectangle ($wa.Right - $w), $wa.Top, $w, $wa.Height
}

# ---- 資料檔（位置可自訂）：nudge-data.json，每次存檔前自動備份到同資料夾的 backups\ ----
$ptrFile = Join-Path $dataDir 'datapath.txt'      # 內容 = 資料所在的資料夾；沒有這個檔就用預設位置
$defaultData = Join-Path $dataDir 'data'
function Get-DataDir {
  try { $p = (Get-Content -LiteralPath $ptrFile -Raw -ErrorAction Stop).Trim(); if ($p) { return $p } } catch {}
  return $defaultData
}
function Get-DataFile { Join-Path (Get-DataDir) 'nudge-data.json' }
function Test-StateJson([string]$text) {
  try { $o = $text | ConvertFrom-Json; return ($null -ne $o -and $null -ne $o.items) } catch { return $false }
}
function Backup-DataFile([string]$file, [int]$minMinutes = 10) {
  if (-not (Test-Path -LiteralPath $file)) { return }
  $bdir = Join-Path (Split-Path $file) 'backups'
  New-Item -ItemType Directory -Force $bdir | Out-Null
  $last = Get-ChildItem -LiteralPath $bdir -Filter 'nudge-*.json' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
  if ($last -and ((Get-Date) - $last.LastWriteTime).TotalMinutes -lt $minMinutes) { return }
  Copy-Item -LiteralPath $file -Destination (Join-Path $bdir ('nudge-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.json'))
  Get-ChildItem -LiteralPath $bdir -Filter 'nudge-*.json' | Sort-Object LastWriteTime -Descending | Select-Object -Skip 40 | Remove-Item -ErrorAction SilentlyContinue
}
function Save-Data([string]$text) {
  if (-not (Test-StateJson $text)) { throw '要儲存的資料格式不正確，已拒絕寫入' }
  $file = Get-DataFile
  New-Item -ItemType Directory -Force (Split-Path $file) | Out-Null
  Backup-DataFile $file
  $tmp = $file + '.tmp'
  [IO.File]::WriteAllText($tmp, $text, (New-Object Text.UTF8Encoding $false))          # 先寫暫存檔，再整個換過去，不會寫到一半
  if (Test-Path -LiteralPath $file) { [IO.File]::Replace($tmp, $file, [NullString]::Value) } else { [IO.File]::Move($tmp, $file) }
}
function Send-Host($obj) {
  try { $script:web.CoreWebView2.PostWebMessageAsString(($obj | ConvertTo-Json -Compress -Depth 4)) } catch { Log $_ }
}
function Send-Data {
  $file = Get-DataFile
  $obj = @{ type = 'data'; version = (Get-AppVersion).ToString(); path = (Split-Path $file); images = (Join-Path (Split-Path $file) 'images'); exists = $false; text = ''; fromBackup = $false; corrupt = $false }
  if (Test-Path -LiteralPath $file) {
    $t = [IO.File]::ReadAllText($file, [Text.Encoding]::UTF8)
    if (Test-StateJson $t) { $obj.exists = $true; $obj.text = $t }
    else {                                                  # 壞檔：另存起來，改讀最近一份有效的備份
      Copy-Item -LiteralPath $file -Destination ($file + '.corrupt-' + (Get-Date -Format 'yyyyMMdd-HHmmss')) -ErrorAction SilentlyContinue
      $bdir = Join-Path (Split-Path $file) 'backups'
      foreach ($b in (Get-ChildItem -LiteralPath $bdir -Filter 'nudge-*.json' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)) {
        $bt = [IO.File]::ReadAllText($b.FullName, [Text.Encoding]::UTF8)
        if (Test-StateJson $bt) { $obj.exists = $true; $obj.text = $bt; $obj.fromBackup = $true; break }
      }
      if (-not $obj.exists) { $obj.corrupt = $true }
    }
  }
  Send-Host $obj
}
# 更換資料位置。mode：existing = 新位置若已有資料就直接用它；overwrite = 用目前的資料覆蓋它（舊檔先備份）
function Set-DataDir([string]$newDir, [string]$mode) {
  $newDir = $newDir.Trim().TrimEnd('\')
  if (-not $newDir) { throw '沒有指定資料夾' }
  try { New-Item -ItemType Directory -Force $newDir -ErrorAction Stop | Out-Null } catch { throw ('找不到或無法建立這個資料夾：' + $newDir) }
  $probe = Join-Path $newDir '.nudge-write-test'
  try { [IO.File]::WriteAllText($probe, 'ok'); Remove-Item -LiteralPath $probe } catch { throw ('這個資料夾無法寫入（沒有權限或磁碟機不存在）：' + $newDir) }     # 寫不進去就拒絕、不更換
  $oldFile = Get-DataFile; $newFile = Join-Path $newDir 'nudge-data.json'
  if ((Split-Path $oldFile) -ieq $newDir) { return }
  if (Test-Path -LiteralPath $newFile) {
    if ($mode -eq 'overwrite') { Backup-DataFile $newFile 0; if (Test-Path -LiteralPath $oldFile) { Copy-Item -LiteralPath $oldFile -Destination $newFile -Force } }
  } elseif (Test-Path -LiteralPath $oldFile) { Copy-Item -LiteralPath $oldFile -Destination $newFile }     # 舊位置的資料不刪，仍留在原處
  $oldImg = Join-Path (Split-Path $oldFile) 'images'      # 貼上的圖片跟著資料走（舊位置的不刪）
  if (Test-Path -LiteralPath $oldImg) { $newImg = Join-Path $newDir 'images'; New-Item -ItemType Directory -Force $newImg | Out-Null; Copy-Item -Path (Join-Path $oldImg '*') -Destination $newImg -Recurse -Force -ErrorAction SilentlyContinue }
  Set-Content -LiteralPath $ptrFile -Value $newDir -Encoding UTF8
}
# 貼上的圖片存成檔案（資料檔只記檔名，不會變肥）
function Save-Image([string]$name, [string]$dataUrl) {
  if ($name -notmatch '^[A-Za-z0-9_-]{4,64}.(jpg|png)$') { throw 'bad image name' }
  $i = $dataUrl.IndexOf(','); if ($i -lt 0 -or -not $dataUrl.StartsWith('data:image/')) { throw 'bad image data' }
  $dir = Join-Path (Get-DataDir) 'images'; New-Item -ItemType Directory -Force $dir | Out-Null
  [IO.File]::WriteAllBytes((Join-Path $dir $name), [Convert]::FromBase64String($dataUrl.Substring($i + 1)))
}
function Choose-DataDir {
  $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
  $dlg.Description = (L '選擇存放 Nudge 資料的資料夾（資料檔名：nudge-data.json）' 'Choose the folder for Nudge data (file name: nudge-data.json)')
  $dlg.SelectedPath = Get-DataDir; $dlg.ShowNewFolderButton = $true
  if ($dlg.ShowDialog($script:form) -ne 'OK') { return }
  $new = $dlg.SelectedPath; $mode = 'existing'
  if (Test-Path -LiteralPath (Join-Path $new 'nudge-data.json')) {
    $msg = L "這個資料夾裡已經有 Nudge 的資料。`n`n【是】使用該資料夾裡的資料（目前這份資料不會被刪除，仍留在原位置）`n【否】用目前的資料覆蓋它（原本那份會先備份）`n【取消】不更換位置" "This folder already contains Nudge data.`n`n[Yes] Use the data in that folder (the current data is not deleted; it stays where it is)`n[No] Overwrite it with the current data (the existing file is backed up first)`n[Cancel] Keep the current location"
    $r = [System.Windows.Forms.MessageBox]::Show($script:form, $msg, (L 'Nudge 資料位置' 'Nudge data location'), 'YesNoCancel', 'Question')
    if ($r -eq 'Cancel') { return }
    $mode = if ($r -eq 'No') { 'overwrite' } else { 'existing' }
  }
  try { Set-DataDir $new $mode; Send-Host @{ type = 'relocated'; path = (Get-DataDir) } }
  catch { Log $_; Send-Host @{ type = 'error'; message = ((L '無法使用這個位置：' 'Cannot use this location: ') + $_.Exception.Message) } }
}

# ---- AI 服務設定與呼叫 ----------------------------------------------------------------------------
# 設定存在 .nudge\llm.json（不放進 git、分享時不帶）。API Key 以 Windows DPAPI 加密（只有「同一個 Windows 使用者」讀得回來），
# 而且金鑰只留在這個外殼裡，不會送進網頁；AI 的網路呼叫也由這裡發出（沒有瀏覽器的跨網域限制，OpenAI／Claude／Gemini／Ollama 都通）。
# 種類：openai = OpenAI 相容（POST {位址}/chat/completions，Bearer 金鑰）；anthropic = Claude 原生（POST {位址}/v1/messages，x-api-key）
Add-Type -AssemblyName System.Net.Http
$llmFile = Join-Path $dataDir 'llm.json'
$script:http = New-Object System.Net.Http.HttpClient
$script:http.Timeout = [TimeSpan]::FromMinutes(10)               # 實際逾時由每次請求自己的 CancellationToken 控制
$script:llmJobs = New-Object System.Collections.ArrayList
$script:llmDown = @{}                                            # 服務 id → 暫時跳過到什麼時候（失敗後 2 分鐘）

function Protect-Key([string]$plain) { if (-not $plain) { return '' }; return (ConvertFrom-SecureString (ConvertTo-SecureString $plain -AsPlainText -Force)) }
function Unprotect-Key([string]$enc) {
  if (-not $enc) { return '' }
  $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR((ConvertTo-SecureString $enc))
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
}
function Read-LlmCfg {
  $cfg = [pscustomobject]@{ providers = @(); timeoutSec = 25; exists = $false }
  if (Test-Path -LiteralPath $llmFile) {
    try {
      $o = [IO.File]::ReadAllText($llmFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
      $cfg.exists = $true
      if ($o.providers) { $cfg.providers = @($o.providers) }
      if ($o.timeoutSec) { $cfg.timeoutSec = [int]$o.timeoutSec }
    } catch { Log $_ }
  }
  return $cfg
}
function Send-LlmCfg {
  $c = Read-LlmCfg; $list = @()
  foreach ($p in $c.providers) { $list += @{ id = [string]$p.id; name = [string]$p.name; type = [string]$p.type; base = [string]$p.base; model = [string]$p.model; enabled = [bool]$p.enabled; noThink = [bool]$p.noThink; hasKey = [bool]$p.keyEnc } }
  Send-Host @{ type = 'llmcfg'; providers = $list; timeoutSec = $c.timeoutSec; exists = $c.exists }     # 注意：不會把金鑰（連加密後的）傳給網頁，只說「有沒有」
}
function Save-LlmCfg($o) {
  $old = Read-LlmCfg; $oldById = @{}
  foreach ($p in $old.providers) { $oldById[[string]$p.id] = $p }
  $out = @()
  foreach ($p in @($o.providers)) {
    $enc = ''
    if ($oldById.ContainsKey([string]$p.id)) { $enc = [string]$oldById[[string]$p.id].keyEnc }       # 沒填新金鑰 = 保留原本的
    if ($p.clearKey) { $enc = '' }
    if ($p.key) { $enc = Protect-Key ([string]$p.key) }
    $out += [ordered]@{ id = [string]$p.id; name = ([string]$p.name).Trim(); type = $(if ($p.type -eq 'anthropic') { 'anthropic' } else { 'openai' })
                        base = ([string]$p.base).Trim(); model = ([string]$p.model).Trim(); enabled = [bool]$p.enabled; noThink = [bool]$p.noThink; keyEnc = $enc }
  }
  $t = 25; try { $t = [Math]::Max(5, [Math]::Min(120, [int]$o.timeoutSec)) } catch {}
  $json = ([ordered]@{ timeoutSec = $t; providers = $out } | ConvertTo-Json -Depth 5)
  New-Item -ItemType Directory -Force (Split-Path $llmFile) | Out-Null
  $tmp = $llmFile + '.tmp'
  [IO.File]::WriteAllText($tmp, $json, (New-Object Text.UTF8Encoding $false))
  if (Test-Path -LiteralPath $llmFile) { [IO.File]::Replace($tmp, $llmFile, [NullString]::Value) } else { [IO.File]::Move($tmp, $llmFile) }
}
function New-LlmProv($p, [string]$keyOverride) {                # 設定檔裡的一筆 → 呼叫時用的物件（金鑰解密後只活在記憶體）
  $key = $keyOverride; if (-not $key -and $p.keyEnc) { try { $key = Unprotect-Key ([string]$p.keyEnc) } catch { Log $_; $key = '' } }
  [pscustomobject]@{ id = [string]$p.id; name = [string]$p.name; type = [string]$p.type; base = [string]$p.base; model = [string]$p.model; noThink = [bool]$p.noThink; key = $key }
}
function New-LlmRequest($p, [string]$system, [string]$user, [int]$maxTokens, $images = @()) {
  $images = @($images | Where-Object { $_ })
  if ($p.type -eq 'anthropic') {
    $base = $(if ($p.base) { $p.base.TrimEnd('/') } else { 'https://api.anthropic.com' })
    $url = $(if ($base -match '/v1/messages$') { $base } else { $base + '/v1/messages' })
    $umsg = $user
    if ($images.Count) {
      $parts = @()
      foreach ($im in $images) { $c = $im.IndexOf(','); $mt = $im.Substring(5, $im.IndexOf(';') - 5); $parts += @{ type = 'image'; source = @{ type = 'base64'; media_type = $mt; data = $im.Substring($c + 1) } } }
      $parts += @{ type = 'text'; text = $user }; $umsg = $parts
    }
    $body = [ordered]@{ model = $p.model; max_tokens = $maxTokens; temperature = 0.2; system = $system; messages = @(@{ role = 'user'; content = $umsg }) }
    $hdr = @{ 'x-api-key' = $p.key; 'anthropic-version' = '2023-06-01' }
  } else {
    $base = ([string]$p.base).TrimEnd('/')
    $url = $(if ($base -match '/chat/completions$') { $base } else { $base + '/chat/completions' })
    $umsg = $user
    if ($images.Count) { $parts = @(@{ type = 'text'; text = $user }); foreach ($im in $images) { $parts += @{ type = 'image_url'; image_url = @{ url = $im } } }; $umsg = $parts }
    $body = [ordered]@{ model = $p.model; temperature = 0.2; max_tokens = $maxTokens; messages = @(@{ role = 'system'; content = $system }, @{ role = 'user'; content = $umsg }) }
    if ($p.noThink) { $body['chat_template_kwargs'] = @{ enable_thinking = $false } }                 # Qwen3 等「思考型」自建模型：關閉思考，否則答案會被思考吃光
    $hdr = @{}; if ($p.key) { $hdr['Authorization'] = 'Bearer ' + $p.key }
  }
  $req = New-Object System.Net.Http.HttpRequestMessage ([System.Net.Http.HttpMethod]::Post), $url
  $req.Content = New-Object System.Net.Http.StringContent (($body | ConvertTo-Json -Depth 6 -Compress)), ([Text.Encoding]::UTF8), 'application/json'
  foreach ($k in $hdr.Keys) { [void]$req.Headers.TryAddWithoutValidation($k, [string]$hdr[$k]) }
  return $req
}
function Get-LlmText($p, [string]$raw) {
  $j = $raw | ConvertFrom-Json
  if ($p.type -eq 'anthropic') { return (($j.content | Where-Object { $_.type -eq 'text' } | ForEach-Object { $_.text }) -join '') }
  return [string]$j.choices[0].message.content
}
function Get-LlmError([int]$status, [string]$raw) {
  $snip = $raw; try { $e = $raw | ConvertFrom-Json; if ($e.error.message) { $snip = [string]$e.error.message } elseif ($e.error) { $snip = [string]$e.error } elseif ($e.message) { $snip = [string]$e.message } } catch {}
  if ($snip.Length -gt 160) { $snip = $snip.Substring(0, 160) + '…' }
  switch ($status) {
    { $_ -in 401, 403 } { return (L "金鑰無效或沒有權限（$status）" "Invalid key or no permission ($status)") }
    404 { return (L "位址或模型名稱不對（404）：$snip" "Wrong base URL or model name (404): $snip") }
    429 { return (L "額度用完或呼叫太頻繁（429）：$snip" "Quota exhausted or too many requests (429): $snip") }
    default { return "HTTP $status：$snip" }
  }
}
function Start-LlmJob($id, $providers, [string]$system, [string]$user, [int]$timeoutSec, [bool]$test, $images = @()) {
  $job = [pscustomobject]@{ id = $id; providers = @($providers); idx = -1; task = $null; cts = $null; sw = $null; req = $null; system = $system; user = $user; images = @($images)
                            timeout = $timeoutSec; test = $test; max = $(if ($test) { 64 } else { 1500 }); errors = (New-Object System.Collections.Generic.List[string]) }
  [void]$script:llmJobs.Add($job); Step-LlmAdvance $job; $script:llmTimer.Start()
}
function Step-LlmAdvance($job) {                                  # 試下一個服務；沒有了就回報失敗
  while ($true) {
    $job.idx++
    if ($job.idx -ge $job.providers.Count) { Complete-LlmJob $job $false '' '' ; return }
    $p = $job.providers[$job.idx]
    try {
      $job.req = New-LlmRequest $p $job.system $job.user $job.max $job.images
      $job.cts = New-Object System.Threading.CancellationTokenSource; $job.cts.CancelAfter($job.timeout * 1000)
      $job.sw = [Diagnostics.Stopwatch]::StartNew(); $job.task = $script:http.SendAsync($job.req, $job.cts.Token); return
    } catch { $job.errors.Add("$($p.name)：$($_.Exception.Message)"); $script:llmDown[$p.id] = (Get-Date).AddMinutes(2) }
  }
}
function Complete-LlmJob($job, [bool]$ok, [string]$content, [string]$used) {
  [void]$script:llmJobs.Remove($job)
  if ($script:llmJobs.Count -eq 0) { $script:llmTimer.Stop() }
  $err = ($job.errors -join '；'); $ms = $(if ($job.sw) { [int]$job.sw.ElapsedMilliseconds } else { 0 })
  if ($job.test) { Send-Host @{ type = 'llmtest'; id = $job.id; ok = $ok; message = $(if ($ok) { '連線成功（' + [Math]::Round($ms / 1000.0, 1) + ' 秒）：' + $content.Trim() } else { $err }); ms = $ms } }
  else { Send-Host @{ type = 'llm'; id = $job.id; ok = $ok; content = $content; used = $used; error = $err } }
}
function Step-LlmJobs {
  foreach ($job in @($script:llmJobs)) {
    if (-not $job.task -or -not $job.task.IsCompleted) { continue }
    $p = $job.providers[$job.idx]
    try {
      if ($job.task.IsCanceled) { throw (L "逾時（超過 $($job.timeout) 秒沒回應）" "Timed out (no response within $($job.timeout) s)") }
      if ($job.task.IsFaulted) { throw $job.task.Exception.GetBaseException().Message }
      $resp = $job.task.Result; $raw = $resp.Content.ReadAsStringAsync().Result
      if (-not $resp.IsSuccessStatusCode) { throw (Get-LlmError ([int]$resp.StatusCode) $raw) }
      $text = Get-LlmText $p $raw
      if (-not $text -or -not $text.Trim()) { throw (L '回覆是空的（若是思考型模型，請勾選「關閉思考模式」）' 'The reply was empty (for a thinking model, tick "Disable thinking mode")') }
      $script:llmDown.Remove($p.id)
      Complete-LlmJob $job $true $text $p.name
    } catch {
      $job.errors.Add("$($p.name)：$($_.Exception.Message)")
      if (-not $job.test) { $script:llmDown[$p.id] = (Get-Date).AddMinutes(2) }
      Step-LlmAdvance $job
    }
  }
}
$script:llmTimer = New-Object System.Windows.Forms.Timer
$script:llmTimer.Interval = 150
$script:llmTimer.add_Tick({ try { Step-LlmJobs } catch { Log $_ } })
. (Join-Path $root 'update.ps1')                                 # 檢查更新／套用更新（手動觸發）

function New-Window {
  $f = New-Object NudgeForm
  $f.Text = 'Nudge'; $f.Icon = $winIcon; $f.ShowInTaskbar = $true
  $f.BackColor = [System.Drawing.Color]::FromArgb(17, 19, 24)
  $f.StartPosition = 'Manual'; $f.MinimumSize = New-Object System.Drawing.Size 420, 420
  $f.MinimizeBox = $true; $f.MaximizeBox = $true
  $script:form = $f
  Set-Dock $script:frac
  # 任何關閉請求（工作列右鍵、Alt+F4…）一律改成隱藏，只有「結束」會真的離開
  $f.add_FormClosing({ param($s, $e) if (-not $script:quitting) { $e.Cancel = $true; Hide-Ui } })

  $w = New-Object Microsoft.Web.WebView2.WinForms.WebView2
  $cp = New-Object Microsoft.Web.WebView2.WinForms.CoreWebView2CreationProperties
  $cp.UserDataFolder = $wvData
  $w.CreationProperties = $cp
  $w.DefaultBackgroundColor = [System.Drawing.Color]::FromArgb(17, 19, 24)
  $w.Dock = 'Fill'
  $f.Controls.Add($w)
  $script:web = $w

  $w.add_CoreWebView2InitializationCompleted({ param($s, $e)
    try {
      if (-not $e.IsSuccess) { Log $e.InitializationException; return }
      $c = $script:web.CoreWebView2
      $c.Settings.IsStatusBarEnabled = $false
      $c.Settings.AreDevToolsEnabled = $false
      # 一次性搬家：把舊版（Edge 視窗）的筆記資料寫入新的 localStorage（只在新資料是空的時候）
      $mig = Join-Path $dataDir 'migrate.json'
      if (Test-Path $mig) {
        $json = [IO.File]::ReadAllText($mig, [Text.Encoding]::UTF8)
        [void]$c.AddScriptToExecuteOnDocumentCreatedAsync("try{var d=$json;if(!localStorage.getItem('attask.v2')&&d['attask.v2']){for(var k in d)localStorage.setItem(k,d[k]);}}catch(e){}")
      }
      $c.add_NavigationCompleted({ param($s2, $e2)
        $m = Join-Path $dataDir 'migrate.json'
        if ($e2.IsSuccess -and (Test-Path $m)) { Move-Item $m (Join-Path $dataDir 'migrate.done') -Force }
      })
      $c.add_WebMessageReceived({ param($s3, $e3)
        $m = $e3.TryGetWebMessageAsString()
        try {
          if ($m.StartsWith('{')) {                              # 資料相關：{"cmd":"load"|"save"|"setpath", ...}
            $o = $m | ConvertFrom-Json
            switch ($o.cmd) {
              'load'    { Send-Data }
              'save'    { Save-Data $o.text; Send-Host @{ type = 'saved'; at = (Get-Date -Format 'HH:mm:ss') } }
              'setpath' { Set-DataDir $o.path $o.mode; Send-Host @{ type = 'relocated'; path = (Get-DataDir) } }
              'saveimg' { Save-Image ([string]$o.name) ([string]$o.data) }
              'llmget'  { Send-LlmCfg }
              'llmsave' { Save-LlmCfg $o; Send-LlmCfg; Send-Host @{ type = 'llmsaved' } }
              'llmtest' {                                          # 測試連線：用畫面上正在編輯的內容（沒填金鑰就用已儲存的）
                $prov = $o.provider; $stored = $null
                foreach ($sp in (Read-LlmCfg).providers) { if ([string]$sp.id -eq [string]$prov.id) { $stored = $sp } }
                $one = [pscustomobject]@{ id = [string]$prov.id; name = [string]$prov.name; type = [string]$prov.type; base = [string]$prov.base; model = [string]$prov.model; noThink = [bool]$prov.noThink
                                          key = $(if ($prov.key) { [string]$prov.key } elseif ($stored -and $stored.keyEnc) { Unprotect-Key ([string]$stored.keyEnc) } else { '' }) }
                Start-LlmJob ('test:' + $prov.id) @($one) '你是連線測試助手。' '請只回覆兩個字母：OK' 20 $true
              }
              'llm' {                                              # AI 分類：依序嘗試已啟用的服務，失敗的暫時跳過 2 分鐘
                $c = Read-LlmCfg; $ps = @()
                foreach ($p in $c.providers) { if ($p.enabled) { $ps += (New-LlmProv $p) } }
                if ($ps.Count -eq 0) { Send-Host @{ type = 'llm'; id = $o.id; ok = $false; error = (L '還沒有啟用的 AI 服務，請到「檔案 → AI 設定…」新增' 'No AI service is enabled; add one under File → AI settings…'); content = ''; used = '' } }
                else {
                  $live = @($ps | Where-Object { -not $script:llmDown.ContainsKey($_.id) -or $script:llmDown[$_.id] -lt (Get-Date) })
                  if ($live.Count -eq 0) { $live = $ps }
                  $imgs = @(); if ($o.images) { $imgs = @($o.images | ForEach-Object { [string]$_ }) }
                  Start-LlmJob $o.id $live ([string]$o.system) ([string]$o.user) $c.timeoutSec $false $imgs
                }
              }
            }
          } else {
            switch ($m) {
              'dock3' { Set-Dock 3 }
              'dock4' { Set-Dock 4 }
              'max'   { $script:form.WindowState = if ($script:form.WindowState -eq 'Maximized') { 'Normal' } else { 'Maximized' } }
              'hide'  { Hide-Ui }
              'datapath'   { Choose-DataDir }
              'datafolder' { New-Item -ItemType Directory -Force (Get-DataDir) | Out-Null; Start-Process explorer.exe -ArgumentList ('"' + (Get-DataDir) + '"') }
              'exit'  { $script:quitting = $true; [System.Windows.Forms.Application]::Exit() }
              { $_ -like 'lang:*' } { Set-Lang ($m.Substring(5)) }
              'update:check' { Start-UpdateCheck }
              'update:go'    { Start-UpdateApply }
            }
          }
        } catch { Log $_; Send-Host @{ type = 'error'; message = $_.Exception.Message } }
      })
      $c.Navigate($page)
    } catch { Log $_ }
  })
  $f.Show()
  [void]$w.EnsureCoreWebView2Async($null)
}

function Show-Ui {
  $idle.Stop()
  if (-not $script:form) { New-Window }
  if (-not $script:form.Visible) { $script:form.Show() }
  if ($script:form.WindowState -eq 'Minimized') { $script:form.WindowState = 'Normal' }
  $script:form.TopMost = $true; $script:form.TopMost = $false   # 拉到最前面
  $script:form.Activate()
}
function Hide-Ui {
  if ($script:form) { $script:form.Hide(); $idle.Start() }
}
# 隱藏超過 2 分鐘就整個釋放（連同 WebView2 程序），下次開啟約 1～2 秒
function Free-Window {
  $idle.Stop()
  if (-not $script:form -or $script:form.Visible) { return }
  $script:quitting = $true
  try { $script:web.Dispose(); $script:form.Dispose() } catch { Log $_ }
  $script:quitting = $false; $script:form = $null; $script:web = $null
  [HotKeyWindow]::Trim()
}
function Toggle-Ui {
  if ($script:form -and $script:form.Visible -and $script:form.WindowState -ne 'Minimized' -and [System.Windows.Forms.Form]::ActiveForm -eq $script:form) { Hide-Ui }
  else { Show-Ui }
}

$idle = New-Object System.Windows.Forms.Timer
$idle.Interval = 120000
$idle.add_Tick({ Free-Window })

$menu = New-Object System.Windows.Forms.ContextMenuStrip
[void]$menu.Items.Add((L '開啟' 'Open'), $null, { Show-Ui })
[void]$menu.Items.Add((L '結束' 'Quit'), $null, { $script:quitting = $true; [System.Windows.Forms.Application]::Exit() })
$script:hkLabel = ''
function Set-Lang([string]$l) {                          # 畫面上切換語言時：記住並更新系統匣選單文字
  $new = if ($l -eq 'en') { 'en' } else { 'zh' }
  if ($new -eq $script:lang) { return }
  $script:lang = $new
  try { Set-Content -LiteralPath $langFile -Value $new -Encoding ASCII } catch {}
  $open = L '開啟' 'Open'; if ($script:hkLabel) { $open += " ($($script:hkLabel))" }
  $menu.Items[0].Text = $open; $menu.Items[1].Text = (L '結束' 'Quit')
}

$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Icon = $icon; $tray.Text = 'Nudge'; $tray.ContextMenuStrip = $menu; $tray.Visible = $true
$tray.add_MouseClick({ if ($_.Button -eq 'Left') { Toggle-Ui } })

# Ctrl(2)+Alt(1)+NoRepeat(0x4000) + 字母鍵；依序嘗試，取第一個沒被占用的
$hk = $null
foreach ($key in 'Q','J','K','G') {
  $try = New-Object HotKeyWindow (0x4003), ([uint32][char]$key)
  if ($try.Ok) { $hk = $try; $hkLabel = "Ctrl+Alt+$key"; break }
  $try.Dispose()
}
if ($hk) {
  $hk.add_Pressed({ try { Toggle-Ui } catch { Log $_ } })
  $script:hkLabel = $hkLabel
  $menu.Items[0].Text = ((L '開啟' 'Open') + " ($hkLabel)")
  $tray.Text = "Nudge ($hkLabel)"
} else {
  $tray.ShowBalloonTip(3000, 'Nudge', (L '快速鍵皆被占用，請用圖示開啟' 'All hotkeys are taken; use the tray icon to open'), 'Warning')
}

# 輕量化：低優先權；啟動後與每 5 分鐘把閒置記憶體還給系統
[System.Diagnostics.Process]::GetCurrentProcess().PriorityClass = 'BelowNormal'
[HotKeyWindow]::Trim()
$trim = New-Object System.Windows.Forms.Timer
$trim.Interval = 300000
$trim.add_Tick({ [HotKeyWindow]::Trim() })
$trim.Start()

[System.Windows.Forms.Application]::Run()

$script:quitting = $true
if ($script:form) { try { $script:web.Dispose(); $script:form.Dispose() } catch {} }
if ($hk) { $hk.Dispose() }; $tray.Visible = $false; $tray.Dispose()
