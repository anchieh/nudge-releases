﻿# 更新檢查與套用（只在你按「檔案 → 檢查更新…」時才連線；不會背景自動查）。
# 流程：抓 version.json 與簽章 version.json.sig → 用內建公鑰（update.pub.xml）驗簽章 → 版本比目前新才提示 →
#       你按同意才下載 zip → 比對 SHA-256 與大小 → 解壓縮到暫存、檢查檔案與語法 → 結束程式，由 apply-update.ps1 備份舊檔、換新檔、重新啟動；失敗會自動還原。
# 這個檔案由 tray.ps1 載入（dot-source），用到 tray.ps1 的 $root、$dataDir、$script:http、Send-Host、Log、L。
$script:UpdateBase = 'https://raw.githubusercontent.com/anchieh/nudge-releases/main/'
$script:upJobs = New-Object System.Collections.ArrayList
$script:upState = @{}

function Get-AppVersion {
  try { return [version]((Get-Content -LiteralPath (Join-Path $root 'VERSION') -ErrorAction Stop | Select-Object -First 1).Trim()) } catch { return [version]'0.0.0' }
}
function Get-UpdateBase {                                  # 測試用：.nudge\update-url.txt 可改成別的位址（結尾要有 /）
  try { $o = (Get-Content -LiteralPath (Join-Path $dataDir 'update-url.txt') -ErrorAction Stop | Select-Object -First 1).Trim(); if ($o) { return $o } } catch {}
  return $script:UpdateBase
}

# ---- 非同步下載（不卡畫面）：用計時器輪詢，完成時呼叫 $done($bytes, $errorText) ----
function Get-BytesAsync([string]$url, [int]$timeoutSec, [scriptblock]$done) {
  $cts = New-Object System.Threading.CancellationTokenSource; $cts.CancelAfter($timeoutSec * 1000)
  $job = [pscustomobject]@{ task = $null; cts = $cts; done = $done; url = $url }
  try { $job.task = $script:http.GetAsync($url, [System.Net.Http.HttpCompletionOption]::ResponseContentRead, $cts.Token) }
  catch { & $done $null $_.Exception.Message; return }
  [void]$script:upJobs.Add($job); $script:upTimer.Start()
}
function Step-UpdateJobs {
  foreach ($job in @($script:upJobs)) {
    if (-not $job.task.IsCompleted) { continue }
    [void]$script:upJobs.Remove($job)
    $bytes = $null; $err = $null
    try {
      if ($job.task.IsCanceled) { throw (L '逾時，沒有回應' 'Timed out') }
      if ($job.task.IsFaulted) { throw $job.task.Exception.GetBaseException().Message }
      $resp = $job.task.Result
      if (-not $resp.IsSuccessStatusCode) { throw ('HTTP ' + [int]$resp.StatusCode) }
      $bytes = $resp.Content.ReadAsByteArrayAsync().Result
    } catch { $err = $_.Exception.Message }
    finally { $job.cts.Dispose() }
    try { & $job.done $bytes $err } catch { Log $_; Send-Host @{ type = 'update'; state = 'error'; message = $_.Exception.Message } }
  }
  if ($script:upJobs.Count -eq 0) { $script:upTimer.Stop() }
}
$script:upTimer = New-Object System.Windows.Forms.Timer
$script:upTimer.Interval = 200
$script:upTimer.add_Tick({ try { Step-UpdateJobs } catch { Log $_ } })

function Send-UpdateError([string]$msg) { Send-Host @{ type = 'update'; state = 'error'; message = $msg } }

# ---- 簽章：RSA-SHA256，簽的是 version.json 的原始位元組；公鑰內建在 update.pub.xml ----
function Test-ManifestSignature([byte[]]$data, [byte[]]$sig) {
  $pubFile = Join-Path $root 'update.pub.xml'
  if (-not (Test-Path -LiteralPath $pubFile)) { throw (L '這份程式沒有內建更新驗證公鑰（update.pub.xml），無法驗證更新' 'This copy has no built-in update public key (update.pub.xml); cannot verify updates') }
  $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
  try { $rsa.FromXmlString([IO.File]::ReadAllText($pubFile)); return $rsa.VerifyData($data, 'SHA256', $sig) } finally { $rsa.Dispose() }
}

function Start-UpdateCheck {
  $script:upState = @{}
  Send-Host @{ type = 'update'; state = 'checking' }
  $base = Get-UpdateBase
  Get-BytesAsync ($base + 'version.json') 15 {
    param($b, $e)
    if ($e) { Send-UpdateError ((L '無法連線到更新位置：' 'Cannot reach the update server: ') + $e); return }
    $script:upState.manifest = $b
    Get-BytesAsync ((Get-UpdateBase) + 'version.json.sig') 15 {
      param($b2, $e2)
      if ($e2) { Send-UpdateError ((L '找不到更新簽章：' 'Update signature not found: ') + $e2); return }
      Complete-UpdateCheck $b2
    }
  }
}
function Complete-UpdateCheck([byte[]]$sigText) {
  try { $sig = [Convert]::FromBase64String(([Text.Encoding]::ASCII.GetString($sigText)).Trim()) } catch { Send-UpdateError (L '更新簽章格式不正確，已拒絕' 'Malformed update signature; rejected'); return }
  if (-not (Test-ManifestSignature $script:upState.manifest $sig)) { Send-UpdateError (L '更新簽章不符，已拒絕（可能是假的更新）' 'Update signature does not match; rejected (possibly a forged update)'); return }
  $m = [Text.Encoding]::UTF8.GetString($script:upState.manifest).TrimStart([char]0xFEFF) | ConvertFrom-Json
  try { $remote = [version][string]$m.version } catch { Send-UpdateError (L '更新資訊的版本號格式不正確' 'Invalid version number in the update info'); return }
  $cur = Get-AppVersion
  if ($remote -le $cur) { Send-Host @{ type = 'update'; state = 'uptodate'; version = $cur.ToString() }; return }
  if (([string]$m.zip) -notmatch '^[A-Za-z0-9._-]+\.zip$' -or ([string]$m.sha256) -notmatch '^[0-9A-Fa-f]{64}$') { Send-UpdateError (L '更新資訊內容不完整，已拒絕' 'Incomplete update info; rejected'); return }
  $script:upState.m = $m
  Send-Host @{ type = 'update'; state = 'available'; version = $remote.ToString(); current = $cur.ToString(); notes = [string]$m.notes; size = [int64]$m.size }
}

# ---- 使用者同意後：下載 → 驗證 → 暫存解壓縮 → 交給 apply-update.ps1 ----
function Start-UpdateApply {
  $m = $script:upState.m
  if (-not $m) { Send-UpdateError (L '請先按「檢查更新」' 'Please run "Check for updates" first'); return }
  Send-Host @{ type = 'update'; state = 'downloading'; version = [string]$m.version }
  Get-BytesAsync ((Get-UpdateBase) + [string]$m.zip) 180 {
    param($b, $e)
    if ($e) { Send-UpdateError ((L '下載失敗：' 'Download failed: ') + $e); return }
    try { Install-UpdateZip $b } catch { Log $_; Send-UpdateError $_.Exception.Message }
  }
}
function Install-UpdateZip([byte[]]$zipBytes) {
  $m = $script:upState.m
  if ($m.size -and [int64]$m.size -ne $zipBytes.LongLength) { throw (L '下載的檔案大小不符，已拒絕' 'Downloaded file size does not match; rejected') }
  $sha = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash($zipBytes)).Replace('-', '')
  if ($sha -ine [string]$m.sha256) { throw (L '下載的檔案 SHA-256 不符，已拒絕' 'Downloaded file SHA-256 does not match; rejected') }
  $up = Join-Path $dataDir 'update'; $stage = Join-Path $up 'stage'
  if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
  New-Item -ItemType Directory -Force $stage | Out-Null
  $zipFile = Join-Path $up ('Nudge-' + $m.version + '.zip'); [IO.File]::WriteAllBytes($zipFile, $zipBytes)
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $stageFull = [IO.Path]::GetFullPath($stage).TrimEnd('\') + '\'
  $z = [IO.Compression.ZipFile]::OpenRead($zipFile)
  try {
    foreach ($en in $z.Entries) {
      if (-not $en.Name) { continue }                                     # 資料夾項目
      $dest = [IO.Path]::GetFullPath((Join-Path $stage $en.FullName))
      if (-not $dest.StartsWith($stageFull, [StringComparison]::OrdinalIgnoreCase)) { throw (L '更新檔含有不安全的路徑，已拒絕' 'The update contains an unsafe path; rejected') }
      New-Item -ItemType Directory -Force (Split-Path $dest) | Out-Null
      [IO.Compression.ZipFileExtensions]::ExtractToFile($en, $dest, $true)
    }
  } finally { $z.Dispose() }
  $src = if (Test-Path -LiteralPath (Join-Path $stage 'Nudge\tray.ps1')) { Join-Path $stage 'Nudge' } else { $stage }
  foreach ($need in 'tray.ps1', 'update.ps1', 'ui\index.html', 'VERSION', 'tools\apply-update.ps1') { if (-not (Test-Path -LiteralPath (Join-Path $src $need))) { throw ((L '更新檔缺少必要檔案：' 'The update is missing a required file: ') + $need) } }
  if ((Get-Content -LiteralPath (Join-Path $src 'VERSION') | Select-Object -First 1).Trim() -ne [string]$m.version) { throw (L '更新檔的版本號與更新資訊不一致，已拒絕' 'Version inside the update does not match the update info; rejected') }
  foreach ($ps in 'tray.ps1', 'update.ps1') {                               # 新程式一定要語法正確才換
    $errs = $null; [void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $src $ps), [ref]$null, [ref]$errs)
    if ($errs -and $errs.Count) { throw ((L '更新檔的程式語法有誤，已拒絕：' 'The update has a syntax error; rejected: ') + $ps) }
  }
  $bk = Join-Path $up ('backup-' + (Get-AppVersion).ToString() + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
  $apply = Join-Path $src 'tools\apply-update.ps1'
  $exe = Join-Path $root 'Nudge.exe'
  $args2 = @('-NoProfile', '-NoLogo', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $apply + '"'),
             '-ProcId', $PID, '-Src', ('"' + $src + '"'), '-Dst', ('"' + $root.TrimEnd('\') + '"'), '-Backup', ('"' + $bk + '"'), '-Exe', ('"' + $exe + '"'), '-LogFile', ('"' + (Join-Path $up 'apply.log') + '"'))
  Send-Host @{ type = 'update'; state = 'applying'; version = [string]$m.version }
  Start-Process -FilePath 'powershell.exe' -ArgumentList $args2 -WindowStyle Hidden
  $script:quitting = $true; [System.Windows.Forms.Application]::Exit()
}
